gfortran  -llapacke -llapack -lblas -lm -Wall  input_h2.f90  input_h2o.f90 overlap_matrix.f90 main.f90 -o main.x


################################
